<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'c6-bongiovanni-ivan-agustin' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '9[|It)2%AcLC ^P&]*kaA.?aM1)phn<!C.?lqT7*=%K&|`D[aCt!r<?W3m{S34cZ' );
define( 'SECURE_AUTH_KEY',  '0jRAoe/]HUs(k=eTLvvPNBxM35f~YD=f,HgZN>q8|HJo^cdCrguj6JM/};8eJHpq' );
define( 'LOGGED_IN_KEY',    '=_84JjF5gw]0{;QcY-9z3{;iylgU6!DU3AE*T6a(xi-=FU0087qtzxIpqzG)(c8]' );
define( 'NONCE_KEY',        'hu`ULo2788G.8a>,+uCVpf(6%e1Z)GZ.c35[#3ir{=GAZ(MX>4Tf2gTU1c}*j,r/' );
define( 'AUTH_SALT',        'M&EQ<6yYxE}<opg.cKZ%@WOewkv86QDI;DZ}je~8o1z?_`d?RliP3dBS5u7?/G!1' );
define( 'SECURE_AUTH_SALT', 'VQoI9d]&S,<9*9mP>OwK7P~{:$8s7(k.IC.O&>=/^$|N)8tp#g3r(PB>I,HQ7zG0' );
define( 'LOGGED_IN_SALT',   'fomTJieuNm;c=qr1MPo7{zz@=raz]F}r1h|xNl`[Y*a&(RC>-UrB2IB}!Vy?DeUk' );
define( 'NONCE_SALT',       '~E*$q{0|#GrTgpbt+cs9H}IUbw3Gc=?[g;jz,b9E(UA)5*T(ZoNz%B>M3Y@UjqJ&' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
